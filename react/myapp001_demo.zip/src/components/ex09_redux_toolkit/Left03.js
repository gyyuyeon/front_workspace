import React from "react";
import { useSelector } from "react-redux";

const Left03 = () => {
  //store에 선언된 state을 가지고 온다
  const number = useSelector((state) => state.number.value);

  return (
    <div>
      <h1>Left03:</h1>
      <h1>Number:{number}</h1>
    </div>
  );
};

export default Left03;
