import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  value: "김규연",
};

export const nameSlice = createSlice({
  name: "name",
  initialState,
  reducers: {
    onHandleName: (state, action) => {
      console.log("action", action);
      state.value = action.payload === "김규연" ? "규연" : "김규연";
    },
  },
});

console.log("nameSlice:", nameSlice);
//dispatch에서 사용하기 위해
export const { onHandleName } = nameSlice.actions;
//store에서 사용하기 위해서
export default nameSlice.reducer;
