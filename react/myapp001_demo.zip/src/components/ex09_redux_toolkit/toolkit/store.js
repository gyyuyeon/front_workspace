import { configureStore } from "@reduxjs/toolkit";
import numberReduce from "./numberSlice";
import nameReducer from "./nameSlice";

export const store = configureStore({
  reducer: {
    number: numberReduce,
    name: nameReducer,
  },
});
