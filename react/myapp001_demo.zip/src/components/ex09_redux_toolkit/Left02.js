import React from "react";
import Left03 from "./Left03";

const Left02 = () => {
  return (
    <div>
      <h1>Left02:</h1>
      <Left03 />
    </div>
  );
};

export default Left02;
