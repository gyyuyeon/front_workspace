import React from "react";
import Right02 from "./Right02";

const Right01 = () => {
  return (
    <div>
      <h1>Right01:</h1>
      <Right02 />
    </div>
  );
};

export default Right01;
