import React from 'react';

const MyJsx002 = () => {
  return (
    <>
      <p>start</p>
      <span>!!</span>
    </>
  );
};

export default MyJsx002;
