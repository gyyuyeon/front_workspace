import React from "react";

const Dashboard = () => {
  return (
    <div>
      <h2>DashBoard</h2>
      <p>쿼리스트링</p>
    </div>
  );
};

export default Dashboard;
